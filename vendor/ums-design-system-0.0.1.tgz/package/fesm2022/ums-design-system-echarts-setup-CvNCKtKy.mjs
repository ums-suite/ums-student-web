import * as echarts from 'echarts/core';
export { echarts };
import { LineChart, BarChart, PieChart, HeatmapChart } from 'echarts/charts';
import { GridComponent, TooltipComponent, LegendComponent, CalendarComponent, VisualMapComponent } from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

/**
 * DSYS-16 -- the one place this package imports from Apache ECharts' modular entry points
 * (`echarts/core` + explicit chart/renderer/component registration) rather than the full
 * `echarts` bundle, per design-decisions.md "Charting Engine Selection"'s accepted bundle-size
 * trade-off: ECharts is meaningfully heavier than a minimal bespoke layer, so only the modules
 * this package's chart family actually uses (Line/Bar/Pie for donut/area, Heatmap+Calendar for
 * the attendance/occupancy heatmap, Gauge is intentionally NOT registered -- the Progress ring
 * is built from PieChart instead, see progress-ring's own class doc) are registered, once, here.
 *
 * Every chart component imports `echarts` from this module, never `echarts` or `echarts/core`
 * directly -- so a future chart type only ever needs one new `.use()` registration, in one file.
 */
echarts.use([
    CanvasRenderer,
    LineChart,
    BarChart,
    PieChart,
    HeatmapChart,
    GridComponent,
    TooltipComponent,
    LegendComponent,
    CalendarComponent,
    VisualMapComponent,
]);
//# sourceMappingURL=ums-design-system-echarts-setup-CvNCKtKy.mjs.map
